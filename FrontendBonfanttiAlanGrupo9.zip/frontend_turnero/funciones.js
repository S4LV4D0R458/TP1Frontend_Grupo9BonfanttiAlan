"use strict";

/* ############## 1. Variables y constantes principales ############ */
// Nombre de la clave usada para guardar los turnos en localStorage.
const CLAVE_STORAGE = "turnero_v1";
// Horarios disponibles para asignar un turno - 08 a 17hs.
const HORARIOS = ["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30",
                  "12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30",
                  "16:00","16:30","17:00"];

// Diccionario de servicios disponibles.
const SERVICIOS = {
  "odontologia": "Odontología",
  "patologia-oral": "Patología oral",
  "implantologia": "Implantología",
  "consultas": "Consultas",
};

// Lista principal de turnos cargados por el usuario.
let turnos = [];        // Arreglo de objetos {id, nombre, dni, ...}
// Si hay un ID, el formulario queda para editar; si es null, crea uno nuevo.
let identificacion = null; // null = crear; string = editar ese id

/* ############## DOM ############# */
// Obtener elementos del HTML por su id.
const $ = (id) => document.getElementById(id);
const form = $("form-turno");
const lista = $("lista-turnos");
const mensaje = $("mensaje");

/* ############## Utilidades ############# */

// Muestra mensaje (ok | error | info)
// Muestra avisos para el usuario como turno creado, error de validación, edición cancelada.
function mostrarMensaje(texto, tipo = "info") {
  mensaje.hidden = false;
  mensaje.textContent = texto;
  mensaje.className = `mensaje mensaje--${tipo}`;
  clearTimeout(mostrarMensaje._t);
  mostrarMensaje._t = setTimeout(() => { mensaje.hidden = true; }, 4500);
}

// Muestra u oculta el error de un campo 
// Marca un campo con error cuando faltan datos o son inválidos.
function setError(inputId, texto) {
  const input = $(inputId);
  const err = $("error-" + inputId);
  if (!err) return;
  if (texto) {
    err.textContent = texto;
    err.hidden = false;
    input.setAttribute("aria-invalid", "true");
  } else {
    err.textContent = "";
    err.hidden = true;
    input.removeAttribute("aria-invalid");
  }
}


// Crea un identificador único para cada turno sin depender de backend.
function generarId() {
  return "t-" + Date.now().toString(36) + "-" + Math.floor(Math.random() * 9999);
}

// Fecha de hoy en formato yyyy-mm-dd (para validar y limitar el input)
// Devuelve la fecha actual para restringir fechas pasadas en el formulario.
function hoyISO() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

// Escapa texto para inyectarlo en HTML sin romper el DOM.
function escapar(texto) {
  return String(texto ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ############## Persistencia con localStorage (JSON) ############ */

// Guarda el arreglo `turnos` como JSON string en localStorage.
// Permanece la colección de turnos para que siga disponible al actualizar la página.
function guardarEnStorage() {
  try {
    localStorage.setItem(CLAVE_STORAGE, JSON.stringify(turnos));
  } catch (e) {
    console.error("No se pudo guardar en localStorage:", e);
    mostrarMensaje("No se pudo guardar en este navegador (almacenamiento bloqueado).", "error");
  }
}

// Lee el JSON de localStorage y lo convierte a arreglo. Si está corrupto, lo reinicia.
function cargarDesdeStorage() {
  const crudo = localStorage.getItem(CLAVE_STORAGE);
  if (!crudo) { turnos = []; return; }
  try {
    const datos = JSON.parse(crudo);
    turnos = Array.isArray(datos) ? datos : [];
  } catch (e) {
    console.error("JSON corrupto en localStorage, se reinicia:", e);
    turnos = [];
    localStorage.removeItem(CLAVE_STORAGE);
  }
}

/* ############## Validaciones del formulario ############ */

// Verifica que el turno se cumpla antes de guardar.
function validarTurno(d) {
  let ok = true;

  if (!d.nombre || d.nombre.trim().length < 3) {
    setError("nombre", "Ingresá tu nombre completo (mínimo 3 letras)."); ok = false;
  } else setError("nombre", "");

  if (!/^\d{7,8}$/.test(d.dni.trim())) {
    setError("dni", "El DNI debe tener 7 u 8 números, sin puntos."); ok = false;
  } else setError("dni", "");

  if (d.telefono.trim().replace(/\D/g, "").length < 6) {
    setError("telefono", "Ingresá un teléfono válido (mínimo 6 números)."); ok = false;
  } else setError("telefono", "");

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email.trim())) {
    setError("email", "Ingresá un correo válido, ej.: ana@mail.com."); ok = false;
  } else setError("email", "");

  if (!d.servicio || !SERVICIOS[d.servicio]) {
    setError("servicio", "Seleccioná un servicio de la lista."); ok = false;
  } else setError("servicio", "");

  if (!d.fecha) {
    setError("fecha", "Elegí una fecha."); ok = false;
  } else if (d.fecha < hoyISO()) {
    setError("fecha", "La fecha no puede ser anterior a hoy."); ok = false;
  } else setError("fecha", "");

  if (!d.hora || !HORARIOS.includes(d.hora)) {
    setError("hora", "Seleccioná una hora válida (08:00 a 17:00)."); ok = false;
  } else setError("hora", "");

  // Evita duplicado exacto (mismo servicio + fecha + hora), ignorando el que se edita.
  if (ok) {
    const duplicado = turnos.some((t) =>
      t.id !== identificacion &&
      t.servicio === d.servicio && t.fecha === d.fecha && t.hora === d.hora &&
      t.estado !== "cancelado");
    if (duplicado) {
      setError("hora", "Ese horario ya está ocupado para ese servicio. Elegí otro.");
      ok = false;
    }
  }
  return ok;
}

// Revisa los valores actuales del formulario y devuelve un objeto turno (sin id/estado)
function leerFormulario() {
  return {
    nombre: $("nombre").value.trim(),
    dni: $("dni").value.trim(),
    telefono: $("telefono").value.trim(),
    email: $("email").value.trim(),
    servicio: $("servicio").value,
    prioridad: $("prioridad").value,
    fecha: $("fecha").value,
    hora: $("hora").value,
    notas: $("notas").value.trim(),
  };
}

/* ############## CRUD: crear, leer, actualizar, eliminar ############ */

// Agrega un turno nuevo con estado inicial "pendiente".
function crearTurno(datos) {
  const nuevo = { id: generarId(), estado: "pendiente", creadoEn: new Date().toISOString(), ...datos };
  turnos.push(nuevo);
  guardarEnStorage();
  renderTurnos();
  return nuevo;
}

// Actualiza los datos de un turno existente.
function actualizarTurno(id, datos) {
  const i = turnos.findIndex((t) => t.id === id);
  if (i === -1) return false;
  turnos[i] = { ...turnos[i], ...datos };
  guardarEnStorage();
  renderTurnos();
  return true;
}


// Elimina un turno
function eliminarTurno(id) {
  turnos = turnos.filter((t) => t.id !== id);
  guardarEnStorage();
  renderTurnos();
}

// Cambia el estado de un turno (pendiente, confirmado, cancelado, atendido)
function cambiarEstado(id, estado) {
  const t = turnos.find((x) => x.id === id);
  if (!t) return;
  t.estado = estado;
  guardarEnStorage();
  renderTurnos();
}

// Carga un turno en el formulario para editarlo.
function empezarEdicion(id) {
  const t = turnos.find((x) => x.id === id);
  if (!t) return;
  identificacion = id;
  $("nombre").value = t.nombre;
  $("dni").value = t.dni;
  $("telefono").value = t.telefono;
  $("email").value = t.email;
  $("servicio").value = t.servicio;
  $("prioridad").value = t.prioridad || "normal";
  $("fecha").value = t.fecha;
  $("hora").value = t.hora;
  $("notas").value = t.notas || "";
  actualizarContadorNotas();
  $("btn-guardar").textContent = "Guardar cambios";
  $("btn-cancelar-edicion").hidden = false;
  $("modo-formulario").textContent = `Modo: editando turno de ${t.nombre} (${t.fecha} ${t.hora}).`;
  document.querySelector("#solicitar-turno").scrollIntoView({ behavior: "smooth" });
  mostrarMensaje("Editando turno. Modificá los campos y pulsá «Guardar cambios».", "info");
}

// Cancela la edición
function cancelarEdicion() {
  identificacion = null;
  form.reset();
  fijarFechaMinima();
  actualizarContadorNotas();
  $("btn-guardar").textContent = "Solicitar turno";
  $("btn-cancelar-edicion").hidden = true;
  $("modo-formulario").textContent = "Modo: crear turno nuevo.";
}

/* ############## Filtros y render en el DOM ############ */

// Aplica búsqueda, filtro por servicio/estado y orden al listado.
function obtenerFiltrados() {
  const q = $("busqueda").value.trim().toLowerCase();
  const fServ = $("filtro-servicio").value;
  const fEst = $("filtro-estado").value;
  const orden = $("orden").value;


  // Filtra por texto, servicio y estado
  let listaFiltrada = turnos.filter((t) => {
    const coincideTexto = !q || t.nombre.toLowerCase().includes(q) || t.dni.includes(q);
    const coincideServ = fServ === "todos" || t.servicio === fServ;
    const coincideEst = fEst === "todos" || t.estado === fEst;
    return coincideTexto && coincideServ && coincideEst;
  });

  // Ordena según la opción seleccionada
  if (orden === "fecha-asc") listaFiltrada.sort((a, b) => (a.fecha + a.hora).localeCompare(b.fecha + b.hora));
  if (orden === "fecha-desc") listaFiltrada.sort((a, b) => (b.fecha + b.hora).localeCompare(a.fecha + a.hora));
  if (orden === "nombre-asc") listaFiltrada.sort((a, b) => a.nombre.localeCompare(b.nombre));
  return listaFiltrada;
}

/** Dibuja la lista de turnos, estadísticas y vista JSON. */
// Renderiza toda la interfaz para mostrar los cambios actuales.
function renderTurnos() {
  const datos = obtenerFiltrados();

  // Resumen + estadísticas
  $("resumen-turnos").textContent =
    turnos.length === 0 ? "Aún no hay turnos registrados."
    : datos.length === turnos.length ? `Mostrando ${datos.length} turno(s) de ${turnos.length} en total.`
    : `Mostrando ${datos.length} de ${turnos.length} turno(s) (hay filtros activos).`;

  // Estadísticas de estado
  const statTotal = $("stat-total");
  const statPendientes = $("stat-pendientes");
  const statConfirmados = $("stat-confirmados");
  const statCancelados = $("stat-cancelados");
  if (statTotal) statTotal.textContent = turnos.length;
  if (statPendientes) statPendientes.textContent = turnos.filter((t) => t.estado === "pendiente").length;
  if (statConfirmados) statConfirmados.textContent = turnos.filter((t) => t.estado === "confirmado").length;
  if (statCancelados) statCancelados.textContent = turnos.filter((t) => t.estado === "cancelado").length;

  // Lista (manipulación del DOM con template strings + escapar)
  if (datos.length === 0) {
    lista.innerHTML = `<div class="vacio">
      <p><strong>Sin resultados.</strong></p>
      <p>Probá con otra búsqueda o cargá un turno nuevo arriba.</p></div>`;
  } else {
    lista.innerHTML = datos.map((t) => `
      <article class="turno" data-id="${escapar(t.id)}">
        <section aria-labelledby="turno-${escapar(t.id)}">
          <h3 id="turno-${escapar(t.id)}" class="turno__titulo">${escapar(t.nombre)} <span class="estado estado--${escapar(t.estado)}">${escapar(t.estado)}</span></h3>
          <p class="turno__meta">🗓 ${escapar(t.fecha)} · 🕘 ${escapar(t.hora)} · 🏷 ${escapar(SERVICIOS[t.servicio] || t.servicio)}</p>
          <p class="turno__meta">DNI ${escapar(t.dni)} · Tel ${escapar(t.telefono)} · ${escapar(t.email)}${t.notas ? " · 📝 " + escapar(t.notas) : ""}</p>
        </section>
        <footer class="turno__acciones">
          <button class="btn btn--mini" data-accion="editar" type="button">Editar</button>
          ${t.estado === "pendiente" ? `<button class="btn btn--mini" data-accion="confirmar" type="button">Confirmar</button>` : ""}
          ${t.estado !== "cancelado" && t.estado !== "atendido" ? `<button class="btn btn--mini" data-accion="cancelar" type="button">Cancelar</button>` : ""}
          ${t.estado === "confirmado" ? `<button class="btn btn--mini" data-accion="atender" type="button">Atendido</button>` : ""}
          <button class="btn btn--mini btn--peligro" data-accion="eliminar" type="button">Eliminar</button>
        </footer>
      </article>`).join("");
  }

  // Vista JSON (representación de la información)
  $("vista-json").textContent = JSON.stringify(turnos, null, 2);
  $("json-count").textContent = turnos.length;
}

/* ############## Datos de ejemplo ############ */


// Carga 3 turnos de ejemplo para probar la app
function cargarEjemplos() {
  if (turnos.length > 0 && !confirm("Ya hay turnos cargados. ¿Agregar 3 ejemplos de todos modos?")) return;
  const base = hoyISO();
  turnos.push(
    { id: generarId(), nombre: "Ana Pérez", dni: "30123456", telefono: "11 5555 0101", email: "ana@mail.com", servicio: "odontologia", prioridad: "normal", fecha: base, hora: "09:00", notas: "Primera visita", estado: "pendiente", creadoEn: new Date().toISOString() },
    { id: generarId(), nombre: "Bruno Díaz", dni: "28999888", telefono: "11 5555 0202", email: "bruno@mail.com", servicio: "odontologia", prioridad: "preferencial", fecha: base, hora: "10:30", notas: "", estado: "confirmado", creadoEn: new Date().toISOString() },
    { id: generarId(), nombre: "Carla Ruiz", dni: "35222111", telefono: "11 5555 0303", email: "carla@mail.com", servicio: "patologia-oral", prioridad: "normal", fecha: base, hora: "11:00", notas: "Consulta de patología oral", estado: "pendiente", creadoEn: new Date().toISOString() },
  );
  guardarEnStorage();
  renderTurnos();
  mostrarMensaje("Se cargaron 3 turnos de ejemplo.", "ok");
}

// Exporta el arreglo de turnos como un archivo JSON
function exportarJSON() {
  const blob = new Blob([JSON.stringify(turnos, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "turnos.json";
  a.click();
  URL.revokeObjectURL(a.href);
}

/* ############## Inicializar  y eventos ############ */

// Carga los horarios disponibles
function cargarHorarios() {
  const sel = $("hora");
  HORARIOS.forEach((h) => {
    const op = document.createElement("option");
    op.value = h; op.textContent = h;
    sel.appendChild(op);
  });
}

// Fija la fecha mínima del input de fecha actual (no se pueden con fechas pasadas)
function fijarFechaMinima() {
  $("fecha").min = hoyISO();
}

// Actualiza el contador de caracteres de las notas
function actualizarContadorNotas() {
  $("contador-notas").textContent = `${$("notas").value.length} / 200 caracteres`;
}

// Inicializa la app y conecta los eventos del formulario y la lista.
function init() {
  cargarHorarios();
  fijarFechaMinima();
  cargarDesdeStorage();
  renderTurnos();

  // Evento SUBMIT: crear o guardar edición, con validación.
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const datos = leerFormulario();
    if (!validarTurno(datos)) {
      mostrarMensaje("Revisá los campos marcados en rojo.", "error");
      document.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }
    if (identificacion) {
      actualizarTurno(identificacion, datos);
      mostrarMensaje("Turno actualizado correctamente.", "ok");
      cancelarEdicion();
    } else {
      const nuevo = crearTurno(datos);
      mostrarMensaje(`Turno registrado para ${nuevo.nombre} el ${nuevo.fecha} a las ${nuevo.hora}.`, "ok");
      form.reset();
      fijarFechaMinima();
      actualizarContadorNotas();
    }
  });

  // Evento CLICK con delegación: editar / confirmar / cancelar / atender / eliminar.
  lista.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-accion]");
    if (!btn) return;
    const id = btn.closest(".turno")?.dataset.id;
    if (!id) return;
    const accion = btn.dataset.accion;
    const t = turnos.find((x) => x.id === id);

    if (accion === "editar") empezarEdicion(id);
    else if (accion === "confirmar") { cambiarEstado(id, "confirmado"); mostrarMensaje(`Turno de ${t?.nombre} confirmado.`, "ok"); }
    else if (accion === "cancelar") { cambiarEstado(id, "cancelado"); mostrarMensaje(`Turno de ${t?.nombre} cancelado.`, "info"); }
    else if (accion === "atender") { cambiarEstado(id, "atendido"); mostrarMensaje(`Turno de ${t?.nombre} marcado como atendido.`, "ok"); }
    else if (accion === "eliminar") {
      if (confirm(`¿Eliminar el turno de ${t?.nombre} (${t?.fecha} ${t?.hora})?`)) {
        eliminarTurno(id);
        if (identificacion === id) cancelarEdicion();
        mostrarMensaje("Turno eliminado.", "info");
      }
    }
  });

  // Eventos INPUT (búsqueda en vivo + contador) y CHANGE (filtros/orden).
  $("busqueda").addEventListener("input", renderTurnos);
  $("notas").addEventListener("input", actualizarContadorNotas);
  ["filtro-servicio", "filtro-estado", "orden"].forEach((id) =>
    $(id).addEventListener("change", renderTurnos));

  // Botones secundarios
  $("btn-cancelar-edicion").addEventListener("click", () => { cancelarEdicion(); mostrarMensaje("Edición cancelada.", "info"); });
  $("btn-borrar-todo").addEventListener("click", () => {
    if (turnos.length === 0) { mostrarMensaje("No hay turnos para borrar.", "info"); return; }
    if (confirm(`¿Borrar los ${turnos.length} turno(s)? Esta acción no se puede deshacer.`)) {
      turnos = []; identificacion = null;
      guardarEnStorage(); cancelarEdicion(); renderTurnos();
      mostrarMensaje("Se eliminaron todos los turnos.", "info");
    }
  });

  $("btn-ejemplos")?.addEventListener("click", cargarEjemplos);
  $("btn-exportar").addEventListener("click", exportarJSON);
  $("btn-copiar").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(JSON.stringify(turnos, null, 2)); 
      mostrarMensaje("JSON copiado al portapapeles.", "ok"); 
    } catch { mostrarMensaje("No se pudo copiar. Seleccioná el JSON manualmente.", "error"); }
  });

  console.log("[Turnero] init OK · turnos cargados:", turnos.length);
}

document.addEventListener("DOMContentLoaded", init);